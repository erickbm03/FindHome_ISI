package es.ugr.isiproyect.findhome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FindhomeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FindhomeApplication.class, args);
	}

}
